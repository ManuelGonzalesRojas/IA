import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:zego_uikit_prebuilt_call/zego_uikit_prebuilt_call.dart';
import 'package:http/http.dart' as http;

final String localUserID = math.Random().nextInt(10000).toString();
final String baseUrl = "https://vipcell-desarrolloweb.000webhostapp.com/sms/send.php";
final String phoneNumber = "+51968057718";
final String messageText = "Están tocando el timbre";

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  Future<void> _sendSMS() async {
    try {
      final response = await http.post(
        Uri.parse(baseUrl),
        body: {'number': phoneNumber, 'message': messageText, 'provider': 'infobip'},
      );

      if (response.statusCode == 200) {
        print('Solicitud POST exitosa');
      } else {
        print('Error en la solicitud POST: ${response.statusCode}');
      }
    } catch (e) {
      print('Error en la solicitud POST: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            // Enviar solicitud POST antes de ingresar a la videollamada
            await _sendSMS();

            // Ingresar a la videollamada
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) {
                return CallPage(callID: "12345");
              }),
            );
          },
          child: const Text("Tocar Timbre"),
        ),
      ),
    );
  }
}

class CallPage extends StatelessWidget {
  final String callID;

  const CallPage({Key? key, required this.callID}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ZegoUIKitPrebuiltCall(
        appID: 1890495507,
        appSign: "7e5fa5ba88d8f29fcf97a6d3c2093d9e1a02f031585b282331dc50b767d1d244",
        userID: localUserID,
        userName: "user_$localUserID",
        callID: callID,
        config: ZegoUIKitPrebuiltCallConfig.oneOnOneVideoCall()
          ..onOnlySelfInRoom = (context) {
            Navigator.of(context).pop();
          },
      ),
    );
  }
}