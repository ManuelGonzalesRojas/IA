// TIC TAC TOE - HUMANO VS IA CON ALGORITMO MIN-MAX

function mejorMovimiento() {
    // TURNO DE LA IA
    let bestScore = -Infinity;
    let move;
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        // ¿HAY UN ESPACIO DISPONIBLE?
        if (tabla[i][j] == '') {
          tabla[i][j] = ia;
          let score = minimax(tabla, 0, false);
          tabla[i][j] = '';
          if (score > bestScore) {
            bestScore = score;
            move = { i, j };
          }
        }
      }
    }
    tabla[move.i][move.j] = ia;
    jugadorActual = humano;
  }
  
  let scores = {
    X: 10,
    O: -10,
    empate: 0
  };
  
  function minimax(tabla, depth, isMaximizing) {
    let resultado = comprobarGanador();
    if (resultado !== null) {
      return scores[resultado];
    }
  
    if (isMaximizing) {
      let bestScore = -Infinity;
      for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
          // ¿HAY UN ESPACIO DISPONIBLE?
          if (tabla[i][j] == '') {
            tabla[i][j] = ia;
            let score = minimax(tabla, depth + 1, false);
            tabla[i][j] = '';
            bestScore = max(score, bestScore);
          }
        }
      }
      return bestScore;
    } else {
      let bestScore = Infinity;
      for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
          // ¿HAY UN ESPACIO DISPONIBLE?
          if (tabla[i][j] == '') {
            tabla[i][j] = humano;
            let score = minimax(tabla, depth + 1, true);
            tabla[i][j] = '';
            bestScore = min(score, bestScore);
          }
        }
      }
      return bestScore;
    }
  }
  