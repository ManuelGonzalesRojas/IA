// TIC TAC TOE - HUMANO VS IA CON ALGORITMO MIN-MAX

let tabla = [
    ['', '', ''],
    ['', '', ''],
    ['', '', '']
  ];
  
  let w; // = ALTURA / 3;
  let h; // = ANCHURA / 3;
  
  let ia = 'X';
  let humano = 'O';
  let jugadorActual = humano;
  
  function setup() {
    let titulo = createP('TIC TAC TOE VS IA');
    let canvas = createCanvas(400, 400);
    w = width / 3;
    h = height / 3;
    mejorMovimiento();
  }
  
  function igualar(a, b, c) {
    return a == b && b == c && a != '';
  }
  
  function comprobarGanador() {
    let ganador = null;
  
    // HORIZONTAL
    for (let i = 0; i < 3; i++) {
      if (igualar(tabla[i][0], tabla[i][1], tabla[i][2])) {
        ganador = tabla[i][0];
      }
    }
  
    // VERTICAL
    for (let i = 0; i < 3; i++) {
      if (igualar(tabla[0][i], tabla[1][i], tabla[2][i])) {
        ganador = tabla[0][i];
      }
    }
  
    // DIAGONAL
    if (igualar(tabla[0][0], tabla[1][1], tabla[2][2])) {
      ganador = tabla[0][0];
    }
    if (igualar(tabla[2][0], tabla[1][1], tabla[0][2])) {
      ganador = tabla[2][0];
    }
  
    let espaciosAbiertos = 0;
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        if (tabla[i][j] == '') {
          espaciosAbiertos++;
        }
      }
    }
  
    if (ganador == null && espaciosAbiertos == 0) {
      return 'empate';
    } else {
      return ganador;
    }
  }
  
  function mousePressed() {
    if (jugadorActual == humano) {
      // TURNO DEL HUMANO
      let i = floor(mouseX / w);
      let j = floor(mouseY / h);
      // VALIDANDO TURNO
      if (tabla[i][j] == '') {
        tabla[i][j] = humano;
        jugadorActual = ia;
        mejorMovimiento();
      }
    }
  }
  
  function draw() {
    background(255);
    strokeWeight(4);

    line(w, 0, w, height);
    line(w * 2, 0, w * 2, height);
    line(0, h, width, h);
    line(0, h * 2, width, h * 2);
  
    for (let j = 0; j < 3; j++) {
      for (let i = 0; i < 3; i++) {
        let x = w * i + w / 2;
        let y = h * j + h / 2;
        let espacio = tabla[i][j];
        textSize(32);
        let r = w / 4;
        if (espacio == humano) {
          noFill();
          ellipse(x, y, r * 2);
        } else if (espacio == ia) {
          line(x - r, y - r, x + r, y + r);
          line(x + r, y - r, x - r, y + r);
        }
      }
    }
  
    let resultado = comprobarGanador();
    if (resultado != null) {
      noLoop();
      let resultadoP = createP('');
      if (resultado == 'empate') {
        resultadoP.html('EMPATE!');
        btnJugarNuevamente.style.display = "block";
      } else {
        resultadoP.html(`${resultado} GANA!`);
        btnJugarNuevamente.style.display = "block";
      }
    }
  }
  