package arbolbinariobusqueda;

import java.util.List;
import java.util.ArrayList;
import java.util.Queue;
import java.util.LinkedList;

public class ABBSensores {
    NodoABB raiz;
    
    public ABBSensores(){
        this.raiz = null;
    }
    
    public void agregarSensor(String sensor){
        NodoABB nuevo = new NodoABB();
        nuevo.setSensor(sensor);
        if(raiz == null){
            raiz = nuevo;
        }else{
            NodoABB anterior = null, reco;
            reco = raiz;
            while(reco != null){
                anterior = reco;
                if(sensor.compareToIgnoreCase(reco.getSensor()) < 0){
                    reco = reco.izquierdo;
                }else{
                    reco = reco.derecho;
                }
            }
            if(sensor.compareToIgnoreCase(anterior.getSensor()) < 0){
                anterior.izquierdo = nuevo;
            }else{
                anterior.derecho = nuevo;
            }
        }
    }
    
    // Búsqueda por Profundidad (DFS)
    public List<String> busquedaProfundidad(String sensor) {
        List<String> comparaciones = new ArrayList<>();
        return dfs(this.raiz, sensor, comparaciones);
    }

    private List<String> dfs(NodoABB nodo, String sensor, List<String> comparaciones) {
        if (nodo == null) {
            return comparaciones;
        }

        comparaciones.add(nodo.getSensor());

        if (nodo.getSensor().equals(sensor)) {
            return comparaciones;
        }

        comparaciones = dfs(nodo.izquierdo, sensor, comparaciones);
        if (comparaciones.get(comparaciones.size() - 1).equals(sensor)) {
            return comparaciones;
        }

        return dfs(nodo.derecho, sensor, comparaciones);
    }

    // Búsqueda por Anchura (BFS)
    public List<String> busquedaAnchura(String sensor) {
        List<String> comparaciones = new ArrayList<>();
        Queue<NodoABB> cola = new LinkedList<>();
        cola.add(this.raiz);

        while (!cola.isEmpty()) {
            NodoABB nodoActual = cola.poll();

            if (nodoActual == null) {
                continue;
            }

            comparaciones.add(nodoActual.getSensor());

            if (nodoActual.getSensor().equals(sensor)) {
                return comparaciones;
            }

            cola.add(nodoActual.izquierdo);
            cola.add(nodoActual.derecho);
        }

        return comparaciones;
    }
}
