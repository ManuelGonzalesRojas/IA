package arbolbinariobusqueda;

import java.awt.Graphics;

public class Arbol {
    public Arbol(){
    }
    
    public void dibujarArbol(Graphics g){
        Rectangulo[] r = new Rectangulo[15];
        
        r[0] = new Rectangulo(339, 40, 50, 30);     //MOV
        
        r[1] = new Rectangulo(239, 120, 50, 30);    //LUZ
        r[2] = new Rectangulo(439, 120, 50, 30);    //TEM
        
        r[3] = new Rectangulo(189, 200, 50, 30);    //HUME
        r[4] = new Rectangulo(389, 200, 50, 30);    //PRE
        r[5] = new Rectangulo(489, 200, 50, 30);    //VEL
        
        r[6] = new Rectangulo(139, 280, 50, 30);    //GAS
        r[7] = new Rectangulo(239, 280, 50, 30);    //HUMO
        r[8] = new Rectangulo(339, 280, 50, 30);    //PH
        r[9] = new Rectangulo(439, 280, 50, 30);    //PRO
        
        r[10] = new Rectangulo(89, 360, 50, 30);    //FUE
        r[11] = new Rectangulo(289, 360, 50, 30);   //OXI
        r[12] = new Rectangulo(489, 360, 50, 30);   //SON
        
        r[13] = new Rectangulo(39, 440, 50, 30);   //ACE
        
        r[14] = new Rectangulo(89, 520, 50, 30);   //CO2
        
        for(int i=0; i<15; i++){
            r[i].dibujarRectangulo(g);
        }
        
        Linea[] l = new Linea[14];
        
        l[0] = new Linea(364, 70, 264, 120);
        l[1] = new Linea(364, 70, 464, 120);
        
        l[2] = new Linea(264, 150, 214, 200);
        l[3] = new Linea(464, 150, 414, 200);
        l[4] = new Linea(464, 150, 514, 200);
        
        l[5] = new Linea(214, 230, 164, 280);
        l[6] = new Linea(214, 230, 264, 280);
        l[7] = new Linea(414, 230, 364, 280);
        l[8] = new Linea(414, 230, 464, 280);
        
        l[9] = new Linea(164, 310, 114, 360);
        l[10] = new Linea(364, 310, 314, 360);
        l[11] = new Linea(464, 310, 514, 360);
        
        l[12] = new Linea(114, 390, 64, 440);
        
        l[13] = new Linea(64, 470, 114, 520);
        
        for(int i=0; i<14; i++){
            l[i].dibujarLinea(g);
        }
    }
          
}
