package arbolbinariobusqueda;

public class NodoABB {
    NodoABB izquierdo, derecho;
    String sensor;
    
    public NodoABB(){
        this.izquierdo = null;
        this.derecho = null; 
    }

    public NodoABB getIzquierdo() {
        return izquierdo;
    }

    public void setIzquierdo(NodoABB izquierdo) {
        this.izquierdo = izquierdo;
    }

    public NodoABB getDerecho() {
        return derecho;
    }

    public void setDerecho(NodoABB derecho) {
        this.derecho = derecho;
    }

    public String getSensor() {
        return sensor;
    }

    public void setSensor(String sensor) {
        this.sensor = sensor;
    }
}
